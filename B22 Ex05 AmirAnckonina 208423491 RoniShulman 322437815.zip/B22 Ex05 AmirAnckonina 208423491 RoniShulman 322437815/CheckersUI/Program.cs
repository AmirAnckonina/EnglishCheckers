﻿using System;
using System.Text;

namespace CheckersUI
{
    public class Program
    {
        public static void Main()
       {
            GameManager game = new GameManager();

            game.Run();
        }
    }
}
