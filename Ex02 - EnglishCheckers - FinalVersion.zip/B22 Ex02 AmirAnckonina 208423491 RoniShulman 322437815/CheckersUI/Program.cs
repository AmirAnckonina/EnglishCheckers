﻿using System;
using System.Text;

namespace CheckersUI
{
    class Program
    {
        public static void Main()
        {
            ConsoleUI gameConsoleUI = new ConsoleUI();

            gameConsoleUI.Run();
        }
    }
}
